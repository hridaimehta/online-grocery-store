function goToHomeLink()  {
      var myDomain = "index.html";
      window.location.href = myDomain;  
}

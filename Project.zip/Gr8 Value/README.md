To open our project, you may find index.html under the templates folder.
This folder contains all of our html files.
You may also start at the login page (login_page.html)

Our project uses popups to alert the user. Sometimes the browser may
block these popups. 